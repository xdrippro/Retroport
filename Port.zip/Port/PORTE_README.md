# Porte (J2ME-Loader asosida) — Asphalt 6

Bu loyiha J2ME-Loader (Apache 2.0) yadrosi ustiga qurilgan. Eski o'z dvigatelingiz o'rniga haqiqiy
MIDP/CLDC emulyatori ishlatiladi, shuning uchun JAR haqiqatan ishga tushadi.

## Nima o'zgartirilgan
- `app/src/main/assets/asphalt6_480x800.jar` — o'yin JAR'i.
- `BundledGame.java` — JAR'ni birinchi ishga tushishda jimgina o'rnatadi (dex, res.jar, manifest, profil 480x800 portret).
- `LauncherActivity.java` — yagona LAUNCHER; o'rnatadi va to'g'ridan-to'g'ri `MicroActivity`ni ochadi.
- `AndroidManifest.xml` — LAUNCHER `LauncherActivity`ga ko'chirilgan (MainActivity faqat JAR ochish uchun qoldi).
- `app/build.gradle` — applicationId `com.mobile.porte`; faqat `open` flavor; keystore.properties bo'lmasa debug imzo;
  git'ga bog'liq `generateVersionCode` olib tashlangan; TinySoundFont header'larini avtomatik yuklovchi task.

## Build
1. Android Studio'da `porte-j2me-loader` papkasini oching (Gradle 9.6 / AGP 9.4.1 — yangi Android Studio kerak).
2. SDK 37 va NDK 29.0.14206865 ni o'rnating (Studio so'raydi). JDK 21.
3. Birinchi build'da internet kerak: `tsf.h` va `tml.h` GitHub'dan yuklanadi
   (`app/src/main/cpp/mmapi_tsf/TinySoundFont/`). Yuklanmasa, qo'lda shu papkaga qo'ying.
4. Variant: `openDebug` yoki `openRelease`.

## Eslatma
- Bu muhitda build qilib tekshirilmagan (tarmoq va SDK yo'q).
- Sozlamalarni o'zgartirish: `BundledGame.java` (o'lcham/yo'nalish), o'yin ichidagi menyu orqali profil.
- Asphalt 6 — Gameloft mulki; JAR bilan APKni ommaga tarqatmang.
