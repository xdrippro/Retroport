# Asfalt6-Lite (Tuzatilgan va optimallashtirilgan versiya)

J2ME-Loader'siz, to'g'ridan-to'g'ri APK ichida ishlaydigan yengil J2ME wrapper (Gameloft usuli).

## 🚀 Qilingan asosiy tuzatishlar:
1. **GitHub Actions CI/CD to'g'rilandi**: Android SDK litsenziyalari avtomatik tasdiqlanadi, xato `if [[ ! -d ... ]]` tekshiruvlari olib tashlandi, APK artifact to'g'ri yuklanadi.
2. **Kross-platforma `prepare.py`**: Windows, Linux va macOS tizimlarida `python3` yoki `python` bilan xatosiz ishlaydi.
3. **Gradle Configuration-time xatosi to'g'rilandi**: Yangi checkout'da `app.properties` bo'lmasa ham `defaultConfig` qiymatlari to'g'ri o'qiladi.
4. **`Graphics.java` dagi VCENTER matn xatosi tuzatildi**: Menyu va tugmalardagi matnlar vertikal markazga to'g'ri joylashadi.
5. **`Display.java` dagi `hideNotify()` xatosi tuzatildi**: Yangi ekranga o'tganda avvalgi ekran xavfsiz to'xtatiladi.
6. **WASD va Gamepad boshqaruvi qo'shildi**: Kompyuter klaviaturasi (W, A, S, D, Space, Enter, Q, E) va Bluetooth joystiklar orqali o'ynash mumkin.
7. **`targetSdk 34` (Android 14) ga yangilandi**: Zamonaviy Android versiyalariga to'liq mos keladi.
8. **Keraksiz `.gradle` kesh fayllari tozalandi va `.gitignore` qo'shildi**.

## 🎮 Boshqaruv tugmalari:
- **W / Yuqoriga (UP / 2)**: Gaz berish / Menyuda yuqoriga
- **S / Pastga (DOWN / 8)**: Tormoz / Menyuda pastga
- **A / Chapga (LEFT / 4)**: Chapga burilish
- **D / O'ngga (RIGHT / 6)**: O'ngga burilish
- **Space / Enter / Button A (FIRE / 5)**: Nitro / Tasdiqlash
- **Q / Start (Softkey 1 / Menu)**: Menyu / Pauza
- **E / Back / Esc (Softkey 2)**: Orqaga qaytish
- **Sensorli ekran**: To'g'ridan-to'g'ri ekranga bosish orqali boshqarish.

## 🛠️ APK yaratish (Build):
### 1. GitHub orqali (eng osoni):
Loyihani GitHub'ga yuklang (`main` yoki `master` branch). `Actions` bo'limida avtomatik tarzda APK yig'iladi va yuklab olish uchun tayyor bo'ladi.

### 2. Android Studio yoki Terminal orqali:
```bash
python3 tools/prepare.py game/game.jar .
./gradlew :app:assembleRelease
```
Tayyor APK fayl: `app/build/outputs/apk/release/app-release.apk`
