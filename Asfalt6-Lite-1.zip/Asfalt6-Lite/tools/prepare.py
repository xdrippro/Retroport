#!/usr/bin/env python3
"""
game/game.jar -> app/ (manifest, ikonka, sozlamalar).
Ishlatish: python3 tools/prepare.py game/game.jar .
"""
import sys, os, re, shutil, zipfile, zlib, struct

if len(sys.argv) < 3:
    print("Foydalanish: python3 tools/prepare.py <jar_yo'li> <loyiha_ildizi>")
    sys.exit(1)

jar = sys.argv[1]
root = sys.argv[2]
app = os.path.join(root, 'app')

if not os.path.exists(jar):
    print(f"XATO: '{jar}' fayli topilmadi!")
    sys.exit(1)

def esc(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '\\': out.append('\\\\')
        elif ch == '\n': out.append('\\n')
        elif ch == '\r': out.append('')
        elif o > 126 or o < 32: out.append('\\u%04x' % o)
        elif ch in ':=#!': out.append('\\' + ch)
        else: out.append(ch)
    return ''.join(out)

with zipfile.ZipFile(jar) as z:
    names = z.namelist()
    mf = next((n for n in names if n.upper() == 'META-INF/MANIFEST.MF'), None)
    text = z.read(mf).decode('utf-8', 'replace') if mf else ''
    text = re.sub(r'\r?\n ', '', text.replace('\r\n', '\n'))
    attrs = {}
    for line in text.split('\n'):
        if ':' in line:
            k, v = line.split(':', 1)
            attrs[k.strip()] = v.strip()

    if 'MIDlet-1' not in attrs:
        sys.exit("XATO: jar MANIFEST.MF da MIDlet-1 parametri topilmadi!")

    parts = [p.strip() for p in attrs['MIDlet-1'].split(',')]
    midlet_cls = parts[-1]
    icon_path = (parts[1] if len(parts) > 2 and parts[1] else attrs.get('MIDlet-Icon', '/icon.png')).lstrip('/')
    icon = z.read(icon_path) if icon_path in names else None

name = attrs.get('MIDlet-Name', os.path.splitext(os.path.basename(jar))[0])
version = attrs.get('MIDlet-Version', '1.0')

# game.properties
cfg = {'width': '240', 'height': '320', 'orientation': 'portrait', 'debug': '1'}
gp = os.path.join(os.path.dirname(os.path.abspath(jar)), 'game.properties')
if os.path.exists(gp):
    with open(gp, 'r', encoding='utf-8', errors='ignore') as f:
        for l in f:
            l = l.strip()
            if l and not l.startswith('#') and '=' in l:
                k, v = l.split('=', 1)
                cfg[k.strip()] = v.strip()

# assets/midlet.properties
assets_dir = os.path.join(app, 'src/main/assets')
os.makedirs(assets_dir, exist_ok=True)
with open(os.path.join(assets_dir, 'midlet.properties'), 'w', encoding='utf-8') as f:
    for k, v in attrs.items():
        f.write(f"{esc(k)}={esc(v)}\n")
    f.write(f"x.midlet={esc(midlet_cls)}\n")
    for k in ('width', 'height', 'orientation', 'debug'):
        f.write(f"x.{k}={esc(cfg.get(k, ''))}\n")

# Copy jar to app/libs
libs_dir = os.path.join(app, 'libs')
os.makedirs(libs_dir, exist_ok=True)
dest_jar = os.path.join(libs_dir, 'game.jar')
if os.path.abspath(jar) != os.path.abspath(dest_jar):
    shutil.copy2(jar, dest_jar)

# Ikonka yaratish yoki olish
def png_fallback():
    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    w = h = 48
    raw = b''.join(b'\x00' + b'\xe0\x30\x30\xff' * w for _ in range(h))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')

data = icon if icon and icon[:4] == b'\x89PNG' else png_fallback()
for dens in ('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'):
    d = os.path.join(app, 'src/main/res/mipmap-' + dens)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, 'ic_launcher.png'), 'wb') as f:
        f.write(data)

# app.properties (Gradle o'qiydi)
clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', name.lower())
if not clean_name: clean_name = 'game'
if clean_name[0].isdigit(): clean_name = 'g' + clean_name
appid = f"com.xcore.{clean_name}"

with open(os.path.join(app, 'app.properties'), 'w', encoding='utf-8') as f:
    f.write(f"appId={appid}\nname={name}\nversionName={version}\n")

print(f"Tayyorlandi: [Nomi: {name}] [Versiya: {version}] [Sinf: {midlet_cls}] [AppId: {appid}] [O'lcham: {cfg['width']}x{cfg['height']}]")
