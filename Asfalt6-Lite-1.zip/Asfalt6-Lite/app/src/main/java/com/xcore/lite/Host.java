package com.xcore.lite;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Properties;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.midlet.MIDlet;

/** Wrapper holati: ekran buferi, MIDlet hayot sikli, hodisalar oqimi. */
public final class Host {
    private static final String TAG = "J2MEHost";
    public static volatile int W = 240, H = 320;
    public static Activity act;
    public static GameView view;
    public static Bitmap screenBmp;
    public static Graphics screenG;
    private static Context ctx;
    private static final Properties props = new Properties();
    private static Handler events, main;
    private static MIDlet midlet;
    private static boolean inited, started, paused;

    public static volatile boolean debug = true;
    public static volatile int paints;
    private static volatile long lastErrTime;
    private static final long startTime = System.currentTimeMillis();
    private static final ArrayList<String> logLines = new ArrayList<String>();

    private Host() {}

    public static void log(String s) {
        Log.i(TAG, s);
        synchronized (logLines) {
            if (s.startsWith("ERR")) lastErrTime = System.currentTimeMillis();
            if (!logLines.isEmpty() && logLines.get(logLines.size() - 1).equals(s)) return;
            logLines.add(s);
            while (logLines.size() > 14) logLines.remove(0);
        }
    }
    public static String logText() {
        StringBuilder b = new StringBuilder();
        synchronized (logLines) { for (String l : logLines) b.append(l).append('\n'); }
        return b.toString();
    }
    public static boolean showOverlay() {
        long now = System.currentTimeMillis();
        return debug && (paints == 0 || now - lastErrTime < 15000 || now - startTime < 6000);
    }
    public static String describe(Throwable t) {
        while (t instanceof InvocationTargetException && t.getCause() != null) t = t.getCause();
        StringBuilder b = new StringBuilder(String.valueOf(t));
        StackTraceElement[] st = t.getStackTrace();
        for (int i = 0; i < Math.min(5, st.length); i++) b.append("\n  at ").append(st[i]);
        if (t.getCause() != null) b.append("\n cause: ").append(t.getCause());
        return b.toString();
    }


    public static synchronized void init(Activity a) {
        act = a;
        if (inited) return;
        inited = true;
        ctx = a.getApplicationContext();
        main = new Handler(Looper.getMainLooper());
        try {
            InputStream in = a.getAssets().open("midlet.properties");
            try { props.load(in); } finally { in.close(); }
        } catch (Exception e) { Log.e(TAG, "midlet.properties", e); }
        debug = !"0".equals(props.getProperty("x.debug", "1").trim());
        W = parse("x.width", 240);
        H = parse("x.height", 320);
        screenBmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        screenG = Graphics.forBitmap(screenBmp);
        HandlerThread ht = new HandlerThread("j2me-events");
        ht.start();
        events = new Handler(ht.getLooper());
        log("init " + W + "x" + H + " " + props.getProperty("x.midlet"));
    }

    private static int parse(String k, int d) {
        try { return Integer.parseInt(props.getProperty(k, "").trim()); } catch (Exception e) { return d; }
    }

    public static boolean landscape() { return "landscape".equalsIgnoreCase(props.getProperty("x.orientation", "portrait").trim()); }
    public static String getProperty(String k) { return props.getProperty(k); }
    public static File filesDir() { return ctx.getFilesDir(); }
    public static File cacheDir() { return ctx.getCacheDir(); }
    public static void post(final Runnable r) {
        Runnable w = new Runnable() {
            public void run() {
                try { r.run(); } catch (Throwable t) { log("ERR event: " + describe(t)); }
            }
        };
        if (events != null) events.post(w); else new Thread(w).start();
    }
    public static void repaint() { GameView v = view; if (v != null) v.markDirty(); }
    public static void serviceRepaints() { GameView v = view; if (v != null) v.renderNow(); }

    public static boolean openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception e) { Log.w(TAG, "openUrl", e); }
        return false;
    }

    // ---- MIDlet hayot sikli ----
    public static synchronized void startMidlet() {
        if (started) return;
        started = true;
        new Thread(new Runnable() {
            public void run() {
                try {
                    log("loading " + props.getProperty("x.midlet"));
                    Class<?> c = Class.forName(props.getProperty("x.midlet"));
                    Constructor<?> k = c.getDeclaredConstructor();
                    k.setAccessible(true);
                    midlet = (MIDlet) k.newInstance();
                    log("MIDlet created");
                    if (call("startApp")) log("startApp returned");
                } catch (Throwable t) {
                    log("ERR start: " + describe(t));
                }
            }
        }, "midlet").start();
    }

    private static boolean call(String name, Object... args) {
        try {
            if (midlet == null) return false;
            Method m;
            if (args.length == 0) m = MIDlet.class.getDeclaredMethod(name);
            else m = MIDlet.class.getDeclaredMethod(name, boolean.class);
            m.setAccessible(true);
            m.invoke(midlet, args);
            return true;
        } catch (Throwable t) {
            log("ERR " + name + ": " + describe(t));
            return false;
        }
    }

    public static void onPause() {
        paused = true;
        post(new Runnable() { public void run() {
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchShow(false);
            call("pauseApp");
        } });
    }

    public static void onResume() {
        if (!paused) return;
        paused = false;
        post(new Runnable() { public void run() {
            call("startApp");
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchShow(true);
            repaint();
        } });
    }

    public static void onKey(final int type, final int code) {
        post(new Runnable() { public void run() {
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchKey(type, code);
        } });
    }

    public static void onPointer(final int type, final int x, final int y) {
        post(new Runnable() { public void run() {
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchPointer(type, x, y);
        } });
    }

    private static boolean exiting;

    /** MIDlet.notifyDestroyed(): o'yin o'zi chiqmoqda, destroyApp chaqirilmaydi. */
    public static void exit() { finish(false); }

    /** Activity yopilganda: avval destroyApp(true), keyin chiqish. */
    public static void shutdown() { finish(true); }

    private static void finish(boolean callDestroy) {
        synchronized (Host.class) {
            if (exiting) return;
            exiting = true;
        }
        if (callDestroy) {
            post(new Runnable() { public void run() { call("destroyApp", true); } });
        }
        main.post(new Runnable() {
            public void run() {
                if (act != null) act.finish();
                main.postDelayed(new Runnable() {
                    public void run() { Process.killProcess(Process.myPid()); }
                }, 500);
            }
        });
    }
}
