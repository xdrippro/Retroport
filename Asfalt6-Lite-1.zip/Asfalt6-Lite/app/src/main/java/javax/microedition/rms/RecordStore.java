package javax.microedition.rms;

import com.xcore.lite.Host;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class RecordStore {
    private static final HashMap<String, RecordStore> OPEN = new HashMap<String, RecordStore>();

    private final String name;
    private final File file;
    private final ArrayList<byte[]> records = new ArrayList<byte[]>();
    private int refs = 1;
    private boolean closed = false;
    private int version = 0;

    private RecordStore(String name, File f) { this.name = name; this.file = f; }

    private static File dir() { File d = new File(Host.filesDir(), "rms"); d.mkdirs(); return d; }
    private static File fileFor(String n) { return new File(dir(), n.replaceAll("[^A-Za-z0-9._-]", "_") + ".rs"); }

    public static synchronized RecordStore openRecordStore(String name, boolean create) throws RecordStoreException {
        RecordStore rs = OPEN.get(name);
        if (rs != null) { rs.refs++; return rs; }
        File f = fileFor(name);
        if (!f.exists()) {
            if (!create) throw new RecordStoreNotFoundException(name);
            rs = new RecordStore(name, f);
            rs.save();
        } else {
            rs = new RecordStore(name, f);
            rs.load();
        }
        OPEN.put(name, rs);
        return rs;
    }
    public static synchronized void deleteRecordStore(String name) throws RecordStoreException {
        if (OPEN.containsKey(name)) throw new RecordStoreException("open");
        File f = fileFor(name);
        if (!f.exists()) throw new RecordStoreNotFoundException(name);
        f.delete();
    }
    public static String[] listRecordStores() {
        File[] fs = dir().listFiles();
        if (fs == null) return null;
        ArrayList<String> l = new ArrayList<String>();
        for (File f : fs) if (f.getName().endsWith(".rs")) l.add(f.getName().substring(0, f.getName().length() - 3));
        return l.toArray(new String[0]);
    }

    private void load() throws RecordStoreException {
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)));
            try {
                version = in.readInt();
                int n = in.readInt();
                for (int i = 0; i < n; i++) {
                    int len = in.readInt();
                    if (len < 0) records.add(null);
                    else { byte[] b = new byte[len]; in.readFully(b); records.add(b); }
                }
            } finally { in.close(); }
        } catch (IOException e) { throw new RecordStoreException(e.toString()); }
    }
    private void save() throws RecordStoreException {
        try {
            File tmp = new File(file.getPath() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)));
            try {
                out.writeInt(version);
                out.writeInt(records.size());
                for (byte[] b : records) {
                    if (b == null) out.writeInt(-1);
                    else { out.writeInt(b.length); out.write(b); }
                }
            } finally { out.close(); }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (IOException e) { throw new RecordStoreException(e.toString()); }
    }
    private void check() throws RecordStoreNotOpenException { if (closed) throw new RecordStoreNotOpenException(); }
    private void checkId(int id) throws InvalidRecordIDException {
        if (id < 1 || id > records.size() || records.get(id - 1) == null) throw new InvalidRecordIDException("id " + id);
    }

    public synchronized void closeRecordStore() throws RecordStoreException {
        check();
        synchronized (RecordStore.class) {
            if (--refs <= 0) { closed = true; OPEN.remove(name); }
        }
    }
    public synchronized int getNumRecords() throws RecordStoreNotOpenException {
        check();
        int n = 0;
        for (byte[] b : records) if (b != null) n++;
        return n;
    }
    public synchronized byte[] getRecord(int id) throws RecordStoreException {
        check(); checkId(id);
        return records.get(id - 1).clone();
    }
    public synchronized int addRecord(byte[] data, int off, int len) throws RecordStoreException {
        check();
        byte[] b = new byte[len];
        if (data != null && len > 0) System.arraycopy(data, off, b, 0, len);
        records.add(b);
        version++;
        save();
        return records.size();
    }
    public synchronized void setRecord(int id, byte[] data, int off, int len) throws RecordStoreException {
        check(); checkId(id);
        byte[] b = new byte[len];
        if (data != null && len > 0) System.arraycopy(data, off, b, 0, len);
        records.set(id - 1, b);
        version++;
        save();
    }
    public synchronized void deleteRecord(int id) throws RecordStoreException {
        check(); checkId(id);
        records.set(id - 1, null);
        version++;
        save();
    }
    public synchronized int getNextRecordID() throws RecordStoreException { check(); return records.size() + 1; }
    public synchronized int getSize() throws RecordStoreException {
        check();
        int s = 0;
        for (byte[] b : records) if (b != null) s += b.length;
        return s;
    }
    public int getSizeAvailable() throws RecordStoreException { return 8 * 1024 * 1024; }
    public String getName() { return name; }
    public int getVersion() { return version; }
}
