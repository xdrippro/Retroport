package javax.microedition.media;

import android.media.MediaPlayer;
import java.io.File;

class PlayerImpl implements Player, MediaPlayer.OnCompletionListener {
    private final File file;
    private MediaPlayer mp;
    private int state = UNREALIZED, loops = 1, played = 0;

    PlayerImpl(File f) {
        file = f;
        if (file != null) file.deleteOnExit();
    }

    public synchronized void realize() {
        if (state != UNREALIZED) return;
        try {
            mp = new MediaPlayer();
            mp.setDataSource(file.getAbsolutePath());
            mp.setOnCompletionListener(this);
            state = REALIZED;
        } catch (Exception e) { releaseMp(); }
    }

    public synchronized void prefetch() {
        realize();
        if (mp != null && state == REALIZED) {
            try { mp.prepare(); state = PREFETCHED; } catch (Exception e) { releaseMp(); }
        }
    }

    public synchronized void start() {
        prefetch();
        if (mp != null && state >= PREFETCHED) {
            try {
                if (state == PREFETCHED) {
                    try { mp.seekTo(0); } catch (Exception ignored) {}
                }
                played = 0;
                mp.setLooping(loops == -1);
                mp.start();
                state = STARTED;
            } catch (Exception e) {
                // Audio xatolar o'yinni qotirib qo'ymasligi uchun yumshoq ushlanadi
            }
        }
    }

    public synchronized void stop() {
        if (mp != null && state == STARTED) {
            try { mp.pause(); } catch (Exception ignored) {}
            state = PREFETCHED;
        }
    }

    public synchronized void deallocate() { stop(); }

    public synchronized void close() {
        releaseMp();
        if (file != null && file.exists()) {
            file.delete();
        }
        state = CLOSED;
    }

    public synchronized int getState() { return state; }

    public synchronized void setLoopCount(int n) {
        loops = n;
        if (mp != null) { try { mp.setLooping(n == -1); } catch (Exception ignored) {} }
    }

    public synchronized long setMediaTime(long t) {
        if (mp != null && state >= PREFETCHED) { try { mp.seekTo((int) (t / 1000)); } catch (Exception ignored) {} }
        return t;
    }

    public synchronized void onCompletion(MediaPlayer m) {
        played++;
        if (loops > 1 && played < loops) { try { m.seekTo(0); m.start(); return; } catch (Exception ignored) {} }
        if (state == STARTED) state = PREFETCHED;
    }

    private void releaseMp() {
        if (mp != null) { try { mp.release(); } catch (Exception ignored) {} mp = null; }
        if (state != CLOSED) state = UNREALIZED;
    }
}
