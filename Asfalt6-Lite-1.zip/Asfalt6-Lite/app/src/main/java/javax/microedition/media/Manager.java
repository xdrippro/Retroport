package javax.microedition.media;

import com.xcore.lite.Host;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class Manager {
    private static int counter = 0;
    private Manager() {}

    public static Player createPlayer(InputStream in, String type) throws IOException {
        String ext = ".dat";
        if (type != null) {
            String t = type.toLowerCase();
            if (t.contains("midi") || t.contains("mid")) ext = ".mid";
            else if (t.contains("wav")) ext = ".wav";
            else if (t.contains("amr")) ext = ".amr";
            else if (t.contains("mpeg") || t.contains("mp3")) ext = ".mp3";
            else if (t.contains("aac")) ext = ".aac";
            else if (t.contains("ogg")) ext = ".ogg";
        }
        File f;
        synchronized (Manager.class) { f = new File(Host.cacheDir(), "snd" + (counter++) + ext); }
        FileOutputStream out = new FileOutputStream(f);
        try {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally { out.close(); }
        return new PlayerImpl(f);
    }
}
