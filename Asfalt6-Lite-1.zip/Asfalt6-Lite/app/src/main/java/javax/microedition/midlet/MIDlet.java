package javax.microedition.midlet;

import com.xcore.lite.Host;

public abstract class MIDlet {
    protected MIDlet() {}
    protected abstract void startApp() throws MIDletStateChangeException;
    protected abstract void pauseApp();
    protected abstract void destroyApp(boolean unconditional) throws MIDletStateChangeException;
    public final void notifyDestroyed() { Host.exit(); }
    public final void notifyPaused() {}
    public final void resumeRequest() {}
    public final String getAppProperty(String key) { return Host.getProperty(key); }
    public final boolean platformRequest(String url) { return Host.openUrl(url); }
}
