package javax.microedition.lcdui;

import com.xcore.lite.Host;

public abstract class Canvas extends Displayable {
    public static final int UP = 1, LEFT = 2, DOWN = 6, RIGHT = 5, FIRE = 8, GAME_A = 9, GAME_B = 10, GAME_C = 11, GAME_D = 12;
    public static final int KEY_NUM0 = 48, KEY_NUM1 = 49, KEY_NUM2 = 50, KEY_NUM3 = 51, KEY_NUM4 = 52, KEY_NUM5 = 53,
            KEY_NUM6 = 54, KEY_NUM7 = 55, KEY_NUM8 = 56, KEY_NUM9 = 57, KEY_STAR = 42, KEY_POUND = 35;

    protected Canvas() {}

    protected abstract void paint(Graphics g);
    protected void keyPressed(int keyCode) {}
    protected void keyReleased(int keyCode) {}
    protected void keyRepeated(int keyCode) {}
    protected void pointerPressed(int x, int y) {}
    protected void pointerReleased(int x, int y) {}
    protected void pointerDragged(int x, int y) {}
    protected void showNotify() {}
    protected void hideNotify() {}

    public void repaint() { Host.repaint(); }
    public void repaint(int x, int y, int w, int h) { Host.repaint(); }
    public void serviceRepaints() { Host.serviceRepaints(); }
    public void setFullScreenMode(boolean mode) {}
    public boolean hasPointerEvents() { return true; }
    public boolean hasPointerMotionEvents() { return true; }
    public boolean hasRepeatEvents() { return true; }
    public boolean isDoubleBuffered() { return true; }

    public int getGameAction(int k) {
        switch (k) {
            case -1: case 50: return UP;
            case -2: case 56: return DOWN;
            case -3: case 52: return LEFT;
            case -4: case 54: return RIGHT;
            case -5: case 53: return FIRE;
            case 49: return GAME_A;
            case 51: return GAME_B;
            case 55: return GAME_C;
            case 57: return GAME_D;
        }
        return 0;
    }
    public int getKeyCode(int action) {
        switch (action) {
            case UP: return -1;
            case DOWN: return -2;
            case LEFT: return -3;
            case RIGHT: return -4;
            case FIRE: return -5;
            case GAME_A: return 49;
            case GAME_B: return 51;
            case GAME_C: return 55;
            case GAME_D: return 57;
        }
        return 0;
    }
    public String getKeyName(int k) { return String.valueOf(k); }

    // --- Host tomonidan chaqiriladi ---
    public final void callPaint(Graphics g) { paint(g); }
    public final void dispatchKey(int type, int code) {
        if (type == 0) keyPressed(code); else if (type == 1) keyReleased(code); else keyRepeated(code);
    }
    public final void dispatchPointer(int type, int x, int y) {
        if (type == 0) pointerPressed(x, y); else if (type == 1) pointerReleased(x, y); else pointerDragged(x, y);
    }
    public final void dispatchShow(boolean show) { if (show) showNotify(); else hideNotify(); }
}
