package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

public class Graphics {
    public static final int HCENTER = 1, VCENTER = 2, LEFT = 4, RIGHT = 8, TOP = 16, BOTTOM = 32, BASELINE = 64;
    public static final int SOLID = 0, DOTTED = 1;

    private final android.graphics.Canvas c;
    private final int w, h, base;
    private boolean clipDirty = true;
    private int tx, ty, cl, ct, cr, cb, color = 0xFF000000;
    private final Paint fill = new Paint(), line = new Paint();
    private final Rect rs = new Rect(), rd = new Rect();
    private final RectF rf = new RectF();
    private final Path path = new Path();
    private Font font = Font.getDefaultFont();

    private Graphics(android.graphics.Canvas c, int w, int h) {
        this.c = c; this.w = w; this.h = h;
        base = c.save();
        fill.setStyle(Paint.Style.FILL);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(1f);
        reset();
    }

    public static Graphics forBitmap(Bitmap b) { return new Graphics(new android.graphics.Canvas(b), b.getWidth(), b.getHeight()); }

    public void reset() {
        tx = ty = 0; cl = 0; ct = 0; cr = w; cb = h; clipDirty = true;
        setColor(0); font = Font.getDefaultFont();
    }

    private void applyClip() {
        if (clipDirty) {
            c.restoreToCount(base);
            c.save();
            c.clipRect(cl, ct, cr, cb);
            clipDirty = false;
        }
    }

    public void translate(int x, int y) { tx += x; ty += y; }
    public int getTranslateX() { return tx; }
    public int getTranslateY() { return ty; }

    public void setColor(int rgb) { color = 0xFF000000 | rgb; fill.setColor(color); line.setColor(color); }
    public void setColor(int r, int g, int b) { setColor(((r & 255) << 16) | ((g & 255) << 8) | (b & 255)); }
    public int getColor() { return color & 0xFFFFFF; }
    public int getDisplayColor(int c) { return c & 0xFFFFFF; }

    public void setFont(Font f) { font = f == null ? Font.getDefaultFont() : f; }
    public Font getFont() { return font; }
    public void setStrokeStyle(int s) {}

    public void setClip(int x, int y, int cw, int ch) {
        cl = x + tx; ct = y + ty; cr = cl + Math.max(0, cw); cb = ct + Math.max(0, ch); clipDirty = true;
    }

    public void clipRect(int x, int y, int cw, int ch) {
        cl = Math.max(cl, x + tx); ct = Math.max(ct, y + ty);
        cr = Math.min(cr, x + tx + cw); cb = Math.min(cb, y + ty + ch);
        if (cr < cl) cr = cl;
        if (cb < ct) cb = ct;
        clipDirty = true;
    }

    public int getClipX() { return cl - tx; }
    public int getClipY() { return ct - ty; }
    public int getClipWidth() { return cr - cl; }
    public int getClipHeight() { return cb - ct; }

    public void drawLine(int x1, int y1, int x2, int y2) {
        applyClip();
        c.drawLine(x1 + tx + .5f, y1 + ty + .5f, x2 + tx + .5f, y2 + ty + .5f, line);
    }

    public void fillRect(int x, int y, int rw, int rh) {
        if (rw <= 0 || rh <= 0) return;
        applyClip();
        c.drawRect(x + tx, y + ty, x + tx + rw, y + ty + rh, fill);
    }

    public void drawRect(int x, int y, int rw, int rh) {
        if (rw < 0 || rh < 0) return;
        applyClip();
        c.drawRect(x + tx + .5f, y + ty + .5f, x + tx + rw + .5f, y + ty + rh + .5f, line);
    }

    public void drawRoundRect(int x, int y, int rw, int rh, int aw, int ah) {
        if (rw < 0 || rh < 0) return;
        applyClip();
        rf.set(x + tx + .5f, y + ty + .5f, x + tx + rw + .5f, y + ty + rh + .5f);
        c.drawRoundRect(rf, aw / 2f, ah / 2f, line);
    }

    public void fillRoundRect(int x, int y, int rw, int rh, int aw, int ah) {
        if (rw <= 0 || rh <= 0) return;
        applyClip();
        rf.set(x + tx, y + ty, x + tx + rw, y + ty + rh);
        c.drawRoundRect(rf, aw / 2f, ah / 2f, fill);
    }

    public void drawArc(int x, int y, int aw, int ah, int start, int sweep) {
        if (aw < 0 || ah < 0) return;
        applyClip();
        rf.set(x + tx + .5f, y + ty + .5f, x + tx + aw + .5f, y + ty + ah + .5f);
        c.drawArc(rf, -start, -sweep, false, line);
    }

    public void fillArc(int x, int y, int aw, int ah, int start, int sweep) {
        if (aw <= 0 || ah <= 0) return;
        applyClip();
        rf.set(x + tx, y + ty, x + tx + aw, y + ty + ah);
        c.drawArc(rf, -start, -sweep, true, fill);
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        applyClip();
        path.reset();
        path.moveTo(x1 + tx, y1 + ty);
        path.lineTo(x2 + tx, y2 + ty);
        path.lineTo(x3 + tx, y3 + ty);
        path.close();
        c.drawPath(path, fill);
    }

    public void drawString(String s, int x, int y, int anchor) {
        if (s == null || s.length() == 0) return;
        applyClip();
        Paint p = font.paint;
        p.setColor(color);
        Paint.FontMetricsInt m = p.getFontMetricsInt();
        float tw = p.measureText(s);
        float px = x + tx, py;
        if ((anchor & HCENTER) != 0) px -= tw / 2f; else if ((anchor & RIGHT) != 0) px -= tw;
        if ((anchor & BOTTOM) != 0) py = y + ty - m.descent;
        else if ((anchor & VCENTER) != 0) py = y + ty - (m.ascent + m.descent) / 2f;
        else if ((anchor & BASELINE) != 0) py = y + ty;
        else py = y + ty - m.ascent;
        c.drawText(s, px, py, p);
    }

    public void drawChars(char[] d, int off, int len, int x, int y, int anchor) { drawString(new String(d, off, len), x, y, anchor); }
    public void drawChar(char ch, int x, int y, int anchor) { drawString(String.valueOf(ch), x, y, anchor); }
    public void drawSubstring(String s, int off, int len, int x, int y, int anchor) { drawString(s.substring(off, off + len), x, y, anchor); }

    private static int ax(int x, int iw, int a) { return (a & HCENTER) != 0 ? x - iw / 2 : (a & RIGHT) != 0 ? x - iw : x; }
    private static int ay(int y, int ih, int a) { return (a & VCENTER) != 0 ? y - ih / 2 : (a & BOTTOM) != 0 ? y - ih : y; }

    public void drawImage(Image img, int x, int y, int anchor) {
        if (img == null || img.bmp == null) return;
        applyClip();
        c.drawBitmap(img.bmp, ax(x, img.bmp.getWidth(), anchor) + tx, ay(y, img.bmp.getHeight(), anchor) + ty, null);
    }

    public void drawRegion(Image img, int xs, int ys, int rw, int rh, int tr, int xd, int yd, int anchor) {
        if (img == null || img.bmp == null || rw <= 0 || rh <= 0) return;
        if (xs < 0 || ys < 0 || xs + rw > img.bmp.getWidth() || ys + rh > img.bmp.getHeight()) return;
        boolean swap = (tr & 7) >= 4;
        int dw = swap ? rh : rw, dh = swap ? rw : rh;
        int dx = ax(xd, dw, anchor) + tx, dy = ay(yd, dh, anchor) + ty;
        applyClip();
        if ((tr & 7) == 0) {
            rs.set(xs, ys, xs + rw, ys + rh);
            rd.set(dx, dy, dx + dw, dy + dh);
            c.drawBitmap(img.bmp, rs, rd, null);
            return;
        }
        Matrix m = new Matrix();
        m.setTranslate(-xs, -ys);
        m.postConcat(Image.transformMatrix(tr, rw, rh));
        m.postTranslate(dx, dy);
        c.save();
        c.clipRect(dx, dy, dx + dw, dy + dh);
        c.drawBitmap(img.bmp, m, null);
        c.restore();
    }

    public void drawRGB(int[] rgb, int off, int scan, int x, int y, int rw, int rh, boolean alpha) {
        if (rgb == null || rw <= 0 || rh <= 0) return;
        applyClip();
        if (!alpha) {
            int[] opaque = new int[rw * rh];
            for (int r = 0; r < rh; r++) {
                int srcRow = off + r * scan;
                int dstRow = r * rw;
                for (int col = 0; col < rw; col++) {
                    opaque[dstRow + col] = rgb[srcRow + col] | 0xFF000000;
                }
            }
            c.drawBitmap(opaque, 0, rw, x + tx, y + ty, rw, rh, false, null);
        } else {
            c.drawBitmap(rgb, off, scan, x + tx, y + ty, rw, rh, true, null);
        }
    }
}
