package javax.microedition.lcdui;

import android.graphics.Paint;
import android.graphics.Typeface;
import com.xcore.lite.Host;

public final class Font {
    public static final int FACE_SYSTEM = 0, FACE_MONOSPACE = 32, FACE_PROPORTIONAL = 64;
    public static final int STYLE_PLAIN = 0, STYLE_BOLD = 1, STYLE_ITALIC = 2, STYLE_UNDERLINED = 4;
    public static final int SIZE_MEDIUM = 0, SIZE_SMALL = 8, SIZE_LARGE = 16;

    private static final Font[] CACHE = new Font[3 * 3 * 8];
    final Paint paint = new Paint();
    private final int face, style, size;

    private Font(int face, int style, int size) {
        this.face = face; this.style = style; this.size = size;
        int st = ((style & STYLE_BOLD) != 0 ? Typeface.BOLD : 0) | ((style & STYLE_ITALIC) != 0 ? Typeface.ITALIC : 0);
        Typeface base = face == FACE_MONOSPACE ? Typeface.MONOSPACE : Typeface.SANS_SERIF;
        paint.setTypeface(Typeface.create(base, st));
        paint.setAntiAlias(true);
        paint.setUnderlineText((style & STYLE_UNDERLINED) != 0);
        float k = Math.max(1f, Host.W / 320f);
        paint.setTextSize((size == SIZE_SMALL ? 10 : size == SIZE_LARGE ? 16 : 12) * k);
    }

    public static synchronized Font getFont(int face, int style, int size) {
        int fi = face == FACE_MONOSPACE ? 1 : face == FACE_PROPORTIONAL ? 2 : 0;
        int si = size == SIZE_SMALL ? 1 : size == SIZE_LARGE ? 2 : 0;
        int idx = (fi * 3 + si) * 8 + (style & 7);
        if (CACHE[idx] == null) CACHE[idx] = new Font(face, style, size);
        return CACHE[idx];
    }
    public static Font getDefaultFont() { return getFont(FACE_SYSTEM, STYLE_PLAIN, SIZE_MEDIUM); }

    public int getHeight() { Paint.FontMetricsInt m = paint.getFontMetricsInt(); return m.descent - m.ascent; }
    public int getBaselinePosition() { return -paint.getFontMetricsInt().ascent; }
    public int stringWidth(String s) { return (int) Math.ceil(paint.measureText(s)); }
    public int substringWidth(String s, int off, int len) { return (int) Math.ceil(paint.measureText(s, off, off + len)); }
    public int charWidth(char c) { return (int) Math.ceil(paint.measureText(String.valueOf(c))); }
    public int charsWidth(char[] ch, int off, int len) { return (int) Math.ceil(paint.measureText(ch, off, len)); }
    public int getStyle() { return style; }
    public int getSize() { return size; }
    public int getFace() { return face; }
    public boolean isBold() { return (style & STYLE_BOLD) != 0; }
    public boolean isItalic() { return (style & STYLE_ITALIC) != 0; }
    public boolean isPlain() { return style == 0; }
}
