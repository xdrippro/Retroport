package javax.microedition.lcdui;

import com.xcore.lite.Host;
import javax.microedition.midlet.MIDlet;

public class Display {
    static Display inst;
    static volatile Displayable current;

    public static synchronized Display getDisplay(MIDlet m) {
        if (inst == null) inst = new Display();
        return inst;
    }

    public Displayable getCurrent() { return current; }

    public void setCurrent(final Displayable d) {
        final Displayable prev = current;
        current = d;
        Host.log("setCurrent " + (d == null ? "null" : d.getClass().getName()));
        Host.post(new Runnable() {
            public void run() {
                if (prev instanceof Canvas && prev != d) {
                    ((Canvas) prev).dispatchShow(false);
                }
                if (d instanceof Canvas) {
                    ((Canvas) d).dispatchShow(true);
                }
            }
        });
        Host.repaint();
    }

    public int numColors() { return 16777216; }
    public boolean isColor() { return true; }
}
