package javax.microedition.media;
public interface Player {
    int CLOSED = 0, UNREALIZED = 100, REALIZED = 200, PREFETCHED = 300, STARTED = 400;
    void realize();
    void prefetch();
    void start();
    void stop();
    void deallocate();
    void close();
    int getState();
    void setLoopCount(int count);
    long setMediaTime(long now);
}
