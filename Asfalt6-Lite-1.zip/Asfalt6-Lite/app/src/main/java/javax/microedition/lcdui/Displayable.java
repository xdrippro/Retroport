package javax.microedition.lcdui;

import com.xcore.lite.Host;
import java.util.ArrayList;

public abstract class Displayable {
    final ArrayList<Command> commands = new ArrayList<Command>();
    CommandListener listener;

    public void addCommand(Command c) { if (c != null && !commands.contains(c)) commands.add(c); }
    public void removeCommand(Command c) { commands.remove(c); }
    public void setCommandListener(CommandListener l) { listener = l; }
    public int getWidth() { return Host.W; }
    public int getHeight() { return Host.H; }
    public boolean isShown() { return Display.current == this; }
    protected void sizeChanged(int w, int h) {}

    /** Android BACK/MENU tugmasi uchun: mos command ni chaqiradi. */
    public boolean fireCommand(int... types) {
        CommandListener l = listener;
        if (l == null) return false;
        for (int t : types) {
            for (Command c : commands) {
                if (c.getCommandType() == t) { l.commandAction(c, this); return true; }
            }
        }
        return false;
    }
}
