package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import com.xcore.lite.Host;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Image {
    public static volatile int decOk, decFail;
    Bitmap bmp;
    private final boolean mutable;

    private Image(Bitmap b, boolean mutable) { this.bmp = b; this.mutable = mutable; }

    public static Image createImage(int w, int h) {
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        b.eraseColor(0xFFFFFFFF);
        return new Image(b, true);
    }

    public static Image createImage(byte[] data, int off, int len) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        o.inScaled = false;
        Bitmap b = null;
        try { b = BitmapFactory.decodeByteArray(data, off, len, o); } catch (Throwable t) { Host.log("ERR decode: " + t); }
        if (b == null) {
            decFail++;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(8, len); i++) sb.append(Integer.toHexString(data[off + i] & 255)).append(' ');
            Host.log("ERR image decode len=" + len + " head=" + sb);
            throw new IllegalArgumentException("bad image data");
        }
        decOk++;
        return new Image(b, false);
    }

    public static Image createImage(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        byte[] d = bo.toByteArray();
        return createImage(d, 0, d.length);
    }

    public static Image createImage(String name) throws IOException {
        if (name == null) throw new IOException("Image name is null");
        String path = name.startsWith("/") ? name : "/" + name;
        InputStream in = Image.class.getResourceAsStream(path);
        if (in == null) {
            in = Image.class.getResourceAsStream(name);
        }
        if (in == null && Host.act != null) {
            String assetPath = path.substring(1);
            try { in = Host.act.getAssets().open(assetPath); } catch (Exception ignored) {}
        }
        if (in == null) throw new IOException("Resource not found: " + name);
        try { return createImage(in); } finally { try { in.close(); } catch (Exception ignored) {} }
    }

    public static Image createImage(Image src, int x, int y, int w, int h, int transform) {
        Bitmap b;
        if (transform == 0) b = Bitmap.createBitmap(src.bmp, x, y, w, h);
        else b = Bitmap.createBitmap(src.bmp, x, y, w, h, transformMatrix(transform, w, h), false);
        return new Image(b, false);
    }

    public static Image createRGBImage(int[] rgb, int w, int h, boolean alpha) {
        int[] px = rgb;
        if (!alpha) {
            px = new int[w * h];
            for (int i = 0; i < px.length; i++) px[i] = rgb[i] | 0xFF000000;
        }
        return new Image(Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888), false);
    }

    public Graphics getGraphics() {
        if (!mutable) throw new IllegalStateException("immutable");
        return Graphics.forBitmap(bmp);
    }

    public int getWidth() { return bmp.getWidth(); }
    public int getHeight() { return bmp.getHeight(); }
    public boolean isMutable() { return mutable; }

    public void getRGB(int[] rgb, int off, int scan, int x, int y, int w, int h) { bmp.getPixels(rgb, off, scan, x, y, w, h); }

    /** MIDP transformatsiyalari (0..7) -> Matrix, w*h bo'lak uchun. */
    static Matrix transformMatrix(int t, int w, int h) {
        float[][] v = {
            {1, 0, 0, 0, 1, 0},
            {1, 0, 0, 0, -1, h},     // MIRROR_ROT180
            {-1, 0, w, 0, 1, 0},     // MIRROR
            {-1, 0, w, 0, -1, h},    // ROT180
            {0, 1, 0, 1, 0, 0},      // MIRROR_ROT270
            {0, -1, h, 1, 0, 0},     // ROT90
            {0, 1, 0, -1, 0, w},     // ROT270
            {0, -1, h, -1, 0, w}     // MIRROR_ROT90
        };
        float[] a = v[t & 7];
        Matrix m = new Matrix();
        m.setValues(new float[]{a[0], a[1], a[2], a[3], a[4], a[5], 0, 0, 1});
        return m;
    }
}
