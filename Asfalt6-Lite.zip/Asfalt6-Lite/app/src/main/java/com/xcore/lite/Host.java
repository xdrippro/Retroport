package com.xcore.lite;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.util.Log;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Properties;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.midlet.MIDlet;

/** Wrapper holati: ekran buferi, MIDlet hayot sikli, hodisalar oqimi. */
public final class Host {
    private static final String TAG = "J2MEHost";
    public static volatile int W = 240, H = 320;
    public static Activity act;
    public static GameView view;
    public static Bitmap screenBmp;
    public static Graphics screenG;
    private static Context ctx;
    private static final Properties props = new Properties();
    private static Handler events, main;
    private static MIDlet midlet;
    private static boolean inited, started, paused;

    private Host() {}

    public static synchronized void init(Activity a) {
        act = a;
        if (inited) return;
        inited = true;
        ctx = a.getApplicationContext();
        main = new Handler(Looper.getMainLooper());
        try {
            InputStream in = a.getAssets().open("midlet.properties");
            try { props.load(in); } finally { in.close(); }
        } catch (Exception e) { Log.e(TAG, "midlet.properties", e); }
        W = parse("x.width", 240);
        H = parse("x.height", 320);
        screenBmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        screenG = Graphics.forBitmap(screenBmp);
        HandlerThread ht = new HandlerThread("j2me-events");
        ht.start();
        events = new Handler(ht.getLooper());
    }

    private static int parse(String k, int d) {
        try { return Integer.parseInt(props.getProperty(k, "").trim()); } catch (Exception e) { return d; }
    }

    public static boolean landscape() { return "landscape".equalsIgnoreCase(props.getProperty("x.orientation", "portrait").trim()); }
    public static String getProperty(String k) { return props.getProperty(k); }
    public static File filesDir() { return ctx.getFilesDir(); }
    public static File cacheDir() { return ctx.getCacheDir(); }
    public static void post(Runnable r) { if (events != null) events.post(r); else new Thread(r).start(); }
    public static void repaint() { GameView v = view; if (v != null) v.markDirty(); }
    public static void serviceRepaints() { GameView v = view; if (v != null) v.renderNow(); }

    public static boolean openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception e) { Log.w(TAG, "openUrl", e); }
        return false;
    }

    // ---- MIDlet hayot sikli ----
    public static synchronized void startMidlet() {
        if (started) return;
        started = true;
        new Thread(new Runnable() {
            public void run() {
                try {
                    Class<?> c = Class.forName(props.getProperty("x.midlet"));
                    Constructor<?> k = c.getDeclaredConstructor();
                    k.setAccessible(true);
                    midlet = (MIDlet) k.newInstance();
                    call("startApp");
                } catch (Throwable t) {
                    Log.e(TAG, "MIDlet start failed", t);
                }
            }
        }, "midlet").start();
    }

    private static void call(String name, Object... args) {
        try {
            if (midlet == null) return;
            Method m;
            if (args.length == 0) m = MIDlet.class.getDeclaredMethod(name);
            else m = MIDlet.class.getDeclaredMethod(name, boolean.class);
            m.setAccessible(true);
            m.invoke(midlet, args);
        } catch (Throwable t) { Log.e(TAG, name + " failed", t); }
    }

    public static void onPause() {
        paused = true;
        post(new Runnable() { public void run() {
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchShow(false);
            call("pauseApp");
        } });
    }

    public static void onResume() {
        if (!paused) return;
        paused = false;
        post(new Runnable() { public void run() {
            call("startApp");
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchShow(true);
            repaint();
        } });
    }

    public static void onKey(final int type, final int code) {
        post(new Runnable() { public void run() {
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchKey(type, code);
        } });
    }

    public static void onPointer(final int type, final int x, final int y) {
        post(new Runnable() { public void run() {
            Displayable d = Display.getDisplay(midlet).getCurrent();
            if (d instanceof Canvas) ((Canvas) d).dispatchPointer(type, x, y);
        } });
    }

    private static boolean exiting;

    /** MIDlet.notifyDestroyed(): o'yin o'zi chiqmoqda, destroyApp chaqirilmaydi. */
    public static void exit() { finish(false); }

    /** Activity yopilganda: avval destroyApp(true), keyin chiqish. */
    public static void shutdown() { finish(true); }

    private static void finish(boolean callDestroy) {
        synchronized (Host.class) {
            if (exiting) return;
            exiting = true;
        }
        if (callDestroy) {
            post(new Runnable() { public void run() { call("destroyApp", true); } });
        }
        main.post(new Runnable() {
            public void run() {
                if (act != null) act.finish();
                main.postDelayed(new Runnable() {
                    public void run() { Process.killProcess(Process.myPid()); }
                }, 500);
            }
        });
    }
}
