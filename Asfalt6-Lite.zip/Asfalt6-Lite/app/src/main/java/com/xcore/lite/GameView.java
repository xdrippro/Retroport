package com.xcore.lite;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private final Object lock = new Object();
    private final Object paintLock = new Object();
    private volatile boolean dirty, ready, running;
    private Thread thread;
    private final Rect src = new Rect(0, 0, Host.W, Host.H);
    private final Rect dst = new Rect(0, 0, 1, 1);
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint controlPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GameView(Context c) {
        super(c);
        getHolder().addCallback(this);
        setFocusable(true);
        setFocusableInTouchMode(true);
        controlPaint.setColor(0x55FFFFFF);
        controlPaint.setStyle(Paint.Style.FILL);
    }

    public void markDirty() {
        synchronized (lock) { dirty = true; lock.notifyAll(); }
    }

    public void surfaceCreated(SurfaceHolder h) {
        ready = true;
        running = true;
        thread = new Thread(this, "render");
        thread.start();
        markDirty();
    }

    public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {
        float s = Math.min(w / (float) Host.W, hh / (float) Host.H);
        int dw = Math.round(Host.W * s), dh = Math.round(Host.H * s);
        int l = (w - dw) / 2, t = (hh - dh) / 2;
        dst.set(l, t, l + dw, t + dh);
        markDirty();
    }

    public void surfaceDestroyed(SurfaceHolder h) {
        ready = false;
        running = false;
        markDirty();
        try { if (thread != null) thread.join(500); } catch (InterruptedException ignored) {}
    }

    public void run() {
        while (running) {
            synchronized (lock) {
                if (!dirty) { try { lock.wait(Host.debug ? 300 : 40); } catch (InterruptedException e) { return; } }
            }
            if (!running) break;
            if (dirty) render(true);
            else if (Host.showOverlay()) render(false);
        }
    }

    public void renderNow() { render(true); }

    private void render(boolean paintGame) {
        synchronized (paintLock) {
            if (!ready) return;
            Displayable d = Display.getDisplay(null).getCurrent();
            boolean isCanvas = d instanceof Canvas;
            dirty = false;
            if (isCanvas && paintGame) {
                Host.screenG.reset();
                try {
                    ((Canvas) d).callPaint(Host.screenG);
                    if (++Host.paints == 1) Host.log("first paint OK");
                    if (Host.paints % 15 == 1) samplePixels();
                } catch (Throwable t) {
                    Host.log("ERR paint: " + Host.describe(t));
                }
            }
            SurfaceHolder h = getHolder();
            android.graphics.Canvas c = null;
            try {
                c = h.lockCanvas();
                if (c != null) {
                    c.drawColor(Color.BLACK);
                    if (isCanvas) c.drawBitmap(Host.screenBmp, src, dst, paint);
                    if (Host.showOverlay()) drawOverlay(c, d);
                }
            } catch (Throwable ignored) {
            } finally {
                if (c != null) { try { h.unlockCanvasAndPost(c); } catch (Throwable ignored) {} }
            }
        }
    }

    private void samplePixels() {
        int op = 0, col = 0, w = Host.screenBmp.getWidth(), h = Host.screenBmp.getHeight();
        for (int j = 0; j < 40; j++) {
            for (int i = 0; i < 40; i++) {
                int p = Host.screenBmp.getPixel(i * w / 40, j * h / 40);
                if ((p >>> 24) != 0) op++;
                if ((p & 0xFFFFFF) != 0) col++;
            }
        }
        Host.pxOpaque = op; Host.pxColored = col;
    }

    private void drawOverlay(android.graphics.Canvas c, Displayable d) {
        float size = Math.max(14f, getWidth() / 45f);
        controlPaint.setTextSize(size);
        int maxChars = Math.max(10, (int) (getWidth() / (size * 0.55f)));
        String text = "screen " + Host.W + "x" + Host.H + "  cur=" + (d == null ? "null" : d.getClass().getName())
                + "  paints=" + Host.paints + "\n"
                + "ops " + javax.microedition.lcdui.Graphics.opStats() + "\n"
                + "img ok=" + javax.microedition.lcdui.Image.decOk + " fail=" + javax.microedition.lcdui.Image.decFail
                + " px(opaque/colored of 1600)=" + Host.pxOpaque + "/" + Host.pxColored + "\n" + Host.logText();
        java.util.ArrayList<String> lines = new java.util.ArrayList<String>();
        for (String raw : text.split("\n")) {
            if (raw.length() == 0) continue;
            for (int i = 0; i < raw.length(); i += maxChars) lines.add(raw.substring(i, Math.min(raw.length(), i + maxChars)));
        }
        float lh = size * 1.25f;
        controlPaint.setColor(0xAA000000);
        c.drawRect(0, 0, getWidth(), lines.size() * lh + size * 0.5f, controlPaint);
        float y = size;
        boolean err = false;
        for (String l : lines) {
            if (!l.startsWith(" ")) err = l.startsWith("ERR");
            controlPaint.setColor(err ? 0xFFFF7070 : 0xFFFFFFFF);
            c.drawText(l, 4, y, controlPaint);
            y += lh;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        int type;
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) type = 0;
        else if (a == MotionEvent.ACTION_MOVE) type = 2;
        else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP || a == MotionEvent.ACTION_CANCEL) type = 1;
        else return true;

        int idx = e.getActionIndex();
        float touchX = e.getX(idx);
        float touchY = e.getY(idx);

        int x = Math.round((touchX - dst.left) * Host.W / (float) Math.max(1, dst.width()));
        int y = Math.round((touchY - dst.top) * Host.H / (float) Math.max(1, dst.height()));
        x = Math.max(0, Math.min(Host.W - 1, x));
        y = Math.max(0, Math.min(Host.H - 1, y));

        Host.onPointer(type, x, y);
        return true;
    }
}
