package com.sha256.nvv

import com.sha256.nvv.crypto.Protocol
import org.junit.Assert.*
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class ProtocolTest {

    private val testKey = ByteArray(32).apply {
        for (i in indices) this[i] = (i + 1).toByte()
    }
    private val testKeyBase64 = Base64.getEncoder().encodeToString(testKey)

    @Test
    fun testQrParsing_valid() {
        val qr = "GT2;$testKeyBase64;901234567;1234;Aziz Tracker"
        val config = Protocol.parseQrCode(qr)

        assertNotNull(config)
        assertEquals("901234567", config!!.phone9)
        assertEquals("1234", config.code4)
        assertEquals("Aziz Tracker", config.name)
        assertArrayEquals(testKey, config.keyBytes)
        assertEquals("+998 90 123 45 67", config.formattedPhone())
    }

    @Test
    fun testQrParsing_invalid() {
        // Wrong prefix
        assertNull(Protocol.parseQrCode("GT1;$testKeyBase64;901234567;1234;Tracker"))

        // Short key (16 bytes instead of 32)
        val shortKeyBase64 = Base64.getEncoder().encodeToString(ByteArray(16))
        assertNull(Protocol.parseQrCode("GT2;$shortKeyBase64;901234567;1234;Tracker"))

        // Invalid phone (8 digits)
        assertNull(Protocol.parseQrCode("GT2;$testKeyBase64;90123456;1234;Tracker"))

        // Invalid code (5 digits)
        assertNull(Protocol.parseQrCode("GT2;$testKeyBase64;901234567;12345;Tracker"))

        // Missing fields
        assertNull(Protocol.parseQrCode("GT2;$testKeyBase64;901234567;1234"))
    }

    @Test
    fun testN1RoundTrip() {
        val ts = 1700000000L
        val lat = 41.3110812
        val lng = 69.2405621

        val intLat = Math.round(lat * 1e7).toInt()
        val intLng = Math.round(lng * 1e7).toInt()

        val plaintext = ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN)
            .put(Protocol.TYPE_N1_LOCATION)
            .putInt(ts.toInt())
            .putInt(intLat)
            .putInt(intLng)
            .array()

        // Encrypt with Tracker -> Monitor specs (AAD = 0x01)
        val iv = ByteArray(12).apply { SecureRandom().nextBytes(this) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(testKey, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(Protocol.AAD_TRACKER_TO_MONITOR)
        val cipherAndTag = cipher.doFinal(plaintext)

        val fullPayload = ByteArray(12 + cipherAndTag.size)
        System.arraycopy(iv, 0, fullPayload, 0, 12)
        System.arraycopy(cipherAndTag, 0, fullPayload, 12, cipherAndTag.size)

        val encryptedBody = Base64.getEncoder().encodeToString(fullPayload)

        // Decrypt via Protocol
        val result = Protocol.decryptIncoming(encryptedBody, testKey)
        assertNotNull(result)
        assertTrue(result is Protocol.IncomingMessage.N1Location)

        val n1 = result as Protocol.IncomingMessage.N1Location
        assertEquals(ts, n1.timestampSec)
        assertEquals(lat, n1.latitude, 0.0000001)
        assertEquals(lng, n1.longitude, 0.0000001)
        assertEquals("https://maps.google.com/?q=41.3110812,69.2405621", n1.mapsUrl)
    }

    @Test
    fun testCommandLayout_7bytes_AAD0x02() {
        val ts = 1705000000L
        val code4 = "4321"

        // Build and encrypt JOY command
        val encryptedCmd = Protocol.buildAndEncryptCommand(
            type = Protocol.TYPE_CMD_JOY,
            tsSec = ts,
            code4 = code4,
            keyBytes = testKey
        )

        // Wire length check: 7 bytes plaintext + 12 IV + 16 tag = 35 bytes -> ceil(35/3)*4 = 48 chars
        assertEquals(48, encryptedCmd.length)

        val raw = Base64.getDecoder().decode(encryptedCmd)
        assertEquals(35, raw.size)

        val iv = raw.copyOfRange(0, 12)
        val cipherAndTag = raw.copyOfRange(12, raw.size)

        // Decrypt using AAD = 0x02
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(testKey, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(Protocol.AAD_MONITOR_TO_TRACKER)
        val decryptedPlaintext = cipher.doFinal(cipherAndTag)

        assertEquals(7, decryptedPlaintext.size)

        val buffer = ByteBuffer.wrap(decryptedPlaintext).order(ByteOrder.BIG_ENDIAN)
        val type = buffer.get()
        val parsedTs = buffer.int.toLong() and 0xFFFFFFFFL
        val parsedCode = buffer.short.toInt() and 0xFFFF

        assertEquals(Protocol.TYPE_CMD_JOY, type)
        assertEquals(ts, parsedTs)
        assertEquals(4321, parsedCode)
    }

    @Test
    fun testBigEndianInts() {
        val bytes = ByteArray(4)
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        val value = 0x12345678
        buffer.putInt(value)

        assertEquals(0x12.toByte(), bytes[0])
        assertEquals(0x34.toByte(), bytes[1])
        assertEquals(0x56.toByte(), bytes[2])
        assertEquals(0x78.toByte(), bytes[3])

        val readBuffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        assertEquals(value, readBuffer.int)
    }

    @Test
    fun testMapsLinkFormat_LocaleUS() {
        val lat = 41.3110812345
        val lng = 69.2405621987
        val url = Protocol.buildMapsUrl(lat, lng)

        // Must use decimal points, never comma, exactly 7 decimals
        assertEquals("https://maps.google.com/?q=41.3110812,69.2405621", url)
        assertFalse(url.contains("," + ","))
        assertTrue(url.startsWith("https://maps.google.com/?q="))
    }
}
