package com.sha256.nvv.crypto

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * Hardware-backed secure storage using Android Keystore AES-256-GCM.
 * Protects QR key, tracker code, phone, name, PIN hash, and message history.
 */
class Vault(private val context: Context) {

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val MASTER_KEY_ALIAS = "cryptosms_master"
        private const val PREFS_NAME = "cryptosms_vault_prefs"

        private const val KEY_TRACKER_KEY = "enc_tracker_key"
        private const val KEY_TRACKER_PHONE = "enc_tracker_phone"
        private const val KEY_TRACKER_CODE = "enc_tracker_code"
        private const val KEY_TRACKER_NAME = "enc_tracker_name"

        private const val KEY_PIN_HASH = "enc_pin_hash"
        private const val KEY_PIN_SALT = "enc_pin_salt"
        private const val KEY_FAILED_PIN_ATTEMPTS = "failed_pin_attempts"
        private const val KEY_LOCKOUT_UNTIL_TS = "lockout_until_ts"

        private const val KEY_LAST_SENT_TS = "enc_last_sent_ts"
        private const val KEY_LAST_ACCEPTED_N1_TS = "enc_last_accepted_n1_ts"
        private const val KEY_LAST_ACCEPTED_G7_TS = "enc_last_accepted_g7_ts"

        const val KEY_MESSAGE_HISTORY = "enc_message_history"

        private const val PBKDF2_ITERATIONS = 100000
        private const val PBKDF2_KEY_LENGTH = 256
        private const val INITIAL_LOCKOUT_SEC = 30L
        private const val MAX_LOCKOUT_SEC = 900L // 15 minutes
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val secureRandom = SecureRandom()

    init {
        ensureMasterKey()
    }

    private fun ensureMasterKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(MASTER_KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                ANDROID_KEYSTORE
            )
            val spec = KeyGenParameterSpec.Builder(
                MASTER_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        }
        return (keyStore.getEntry(MASTER_KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    fun encrypt(plaintext: ByteArray): String {
        val masterKey = ensureMasterKey()
        val iv = ByteArray(12)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, masterKey, GCMParameterSpec(128, iv))
        val cipherAndTag = cipher.doFinal(plaintext)

        val ivStr = Base64.getEncoder().encodeToString(iv)
        val cipherStr = Base64.getEncoder().encodeToString(cipherAndTag)
        return "$ivStr:$cipherStr"
    }

    fun decrypt(encoded: String): ByteArray? {
        val parts = encoded.split(":")
        if (parts.size != 2) return null
        return try {
            val iv = Base64.getDecoder().decode(parts[0])
            val cipherAndTag = Base64.getDecoder().decode(parts[1])
            val masterKey = ensureMasterKey()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, masterKey, GCMParameterSpec(128, iv))
            cipher.doFinal(cipherAndTag)
        } catch (_: Exception) {
            null
        }
    }

    fun encryptString(plain: String): String {
        return encrypt(plain.toByteArray(Charsets.UTF_8))
    }

    fun decryptString(encoded: String): String? {
        val bytes = decrypt(encoded) ?: return null
        return String(bytes, Charsets.UTF_8)
    }

    // --- Tracker Pairings ---

    fun saveTrackerConfig(config: Protocol.TrackerConfig) {
        val encKey = encrypt(config.keyBytes)
        val encPhone = encryptString(config.phone9)
        val encCode = encryptString(config.code4)
        val encName = encryptString(config.name)

        prefs.edit()
            .putString(KEY_TRACKER_KEY, encKey)
            .putString(KEY_TRACKER_PHONE, encPhone)
            .putString(KEY_TRACKER_CODE, encCode)
            .putString(KEY_TRACKER_NAME, encName)
            .apply()
    }

    fun getTrackerConfig(): Protocol.TrackerConfig? {
        val encKey = prefs.getString(KEY_TRACKER_KEY, null) ?: return null
        val encPhone = prefs.getString(KEY_TRACKER_PHONE, null) ?: return null
        val encCode = prefs.getString(KEY_TRACKER_CODE, null) ?: return null
        val encName = prefs.getString(KEY_TRACKER_NAME, null) ?: return null

        val keyBytes = decrypt(encKey) ?: return null
        val phone = decryptString(encPhone) ?: return null
        val code = decryptString(encCode) ?: return null
        val name = decryptString(encName) ?: return null

        return Protocol.TrackerConfig(
            keyBytes = keyBytes,
            phone9 = phone,
            code4 = code,
            name = name
        )
    }

    fun isTrackerPaired(): Boolean {
        return prefs.contains(KEY_TRACKER_KEY) && prefs.contains(KEY_TRACKER_PHONE)
    }

    fun clearTrackerConfig() {
        prefs.edit()
            .remove(KEY_TRACKER_KEY)
            .remove(KEY_TRACKER_PHONE)
            .remove(KEY_TRACKER_CODE)
            .remove(KEY_TRACKER_NAME)
            .remove(KEY_MESSAGE_HISTORY)
            .remove(KEY_LAST_SENT_TS)
            .remove(KEY_LAST_ACCEPTED_N1_TS)
            .remove(KEY_LAST_ACCEPTED_G7_TS)
            .apply()
    }

    // --- PIN Management ---

    fun hasPin(): Boolean {
        return prefs.contains(KEY_PIN_HASH) && prefs.contains(KEY_PIN_SALT)
    }

    fun setPin(pin: String) {
        val salt = ByteArray(16)
        secureRandom.nextBytes(salt)
        val hash = hashPin(pin, salt)

        val encHash = encrypt(hash)
        val encSalt = encrypt(salt)

        prefs.edit()
            .putString(KEY_PIN_HASH, encHash)
            .putString(KEY_PIN_SALT, encSalt)
            .putInt(KEY_FAILED_PIN_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL_TS, 0L)
            .apply()
    }

    fun verifyPin(enteredPin: String): Boolean {
        val remainingLockout = getLockoutRemainingSeconds()
        if (remainingLockout > 0) {
            return false
        }

        val encHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val encSalt = prefs.getString(KEY_PIN_SALT, null) ?: return false

        val storedHash = decrypt(encHash) ?: return false
        val salt = decrypt(encSalt) ?: return false

        val enteredHash = hashPin(enteredPin, salt)
        val isValid = MessageDigest.isEqual(storedHash, enteredHash)

        if (isValid) {
            resetLockout()
        } else {
            recordFailedAttempt()
        }
        return isValid
    }

    private fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, PBKDF2_KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun getLockoutRemainingSeconds(): Long {
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL_TS, 0L)
        val now = System.currentTimeMillis()
        if (lockoutUntil > now) {
            return (lockoutUntil - now + 999) / 1000
        }
        return 0L
    }

    private fun recordFailedAttempt(): Long {
        val attempts = prefs.getInt(KEY_FAILED_PIN_ATTEMPTS, 0) + 1
        val editor = prefs.edit()
        editor.putInt(KEY_FAILED_PIN_ATTEMPTS, attempts)

        if (attempts >= 5) {
            // Lockout doubling: 5th attempt = 30s, 6th = 60s, 7th = 120s, up to 15m
            val multiplier = 1L shl (attempts - 5).coerceAtMost(30)
            val lockoutSec = (INITIAL_LOCKOUT_SEC * multiplier).coerceAtMost(MAX_LOCKOUT_SEC)
            val lockoutUntil = System.currentTimeMillis() + (lockoutSec * 1000)
            editor.putLong(KEY_LOCKOUT_UNTIL_TS, lockoutUntil)
            editor.apply()
            return lockoutSec
        } else {
            editor.apply()
            return 0L
        }
    }

    private fun resetLockout() {
        prefs.edit()
            .putInt(KEY_FAILED_PIN_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL_TS, 0L)
            .apply()
    }

    // --- Timestamps ---

    fun getLastSentTs(): Long {
        val enc = prefs.getString(KEY_LAST_SENT_TS, null) ?: return 0L
        return decryptString(enc)?.toLongOrNull() ?: 0L
    }

    fun setLastSentTs(ts: Long) {
        prefs.edit().putString(KEY_LAST_SENT_TS, encryptString(ts.toString())).apply()
    }

    fun getLastAcceptedTsN1(): Long {
        val enc = prefs.getString(KEY_LAST_ACCEPTED_N1_TS, null) ?: return 0L
        return decryptString(enc)?.toLongOrNull() ?: 0L
    }

    fun setLastAcceptedTsN1(ts: Long) {
        prefs.edit().putString(KEY_LAST_ACCEPTED_N1_TS, encryptString(ts.toString())).apply()
    }

    fun getLastAcceptedTsG7(): Long {
        val enc = prefs.getString(KEY_LAST_ACCEPTED_G7_TS, null) ?: return 0L
        return decryptString(enc)?.toLongOrNull() ?: 0L
    }

    fun setLastAcceptedTsG7(ts: Long) {
        prefs.edit().putString(KEY_LAST_ACCEPTED_G7_TS, encryptString(ts.toString())).apply()
    }

    // --- Message History Raw Encrypted Storage ---

    fun getEncryptedHistory(): String? {
        val enc = prefs.getString(KEY_MESSAGE_HISTORY, null) ?: return null
        return decryptString(enc)
    }

    fun saveEncryptedHistory(jsonString: String) {
        prefs.edit().putString(KEY_MESSAGE_HISTORY, encryptString(jsonString)).apply()
    }
}
