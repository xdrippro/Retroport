package com.sha256.nvv.data

import android.content.Context
import com.sha256.nvv.crypto.Vault
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class UiMessage(
    val id: String = UUID.randomUUID().toString(),
    val type: String, // "N1", "G7", "OCHIQ"
    val timestampSec: Long,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val mapsUrl: String? = null,
    val bodyText: String? = null,
    val receivedAtMs: Long = System.currentTimeMillis()
)

class MessageStore(context: Context) {

    private val vault = Vault(context)

    private val _messages = MutableStateFlow<List<UiMessage>>(emptyList())
    val messages: StateFlow<List<UiMessage>> = _messages.asStateFlow()

    init {
        loadMessages()
    }

    @Synchronized
    fun loadMessages() {
        val jsonStr = vault.getEncryptedHistory() ?: return
        try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<UiMessage>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    UiMessage(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        type = obj.getString("type"),
                        timestampSec = obj.getLong("timestampSec"),
                        latitude = if (obj.has("latitude") && !obj.isNull("latitude")) obj.getDouble("latitude") else null,
                        longitude = if (obj.has("longitude") && !obj.isNull("longitude")) obj.getDouble("longitude") else null,
                        mapsUrl = obj.optString("mapsUrl").takeIf { it.isNotEmpty() },
                        bodyText = obj.optString("bodyText").takeIf { it.isNotEmpty() },
                        receivedAtMs = obj.optLong("receivedAtMs", System.currentTimeMillis())
                    )
                )
            }
            // Ensure sorted newest first
            _messages.value = list.sortedByDescending { it.timestampSec }
        } catch (_: Exception) {
            _messages.value = emptyList()
        }
    }

    @Synchronized
    fun addMessage(message: UiMessage) {
        val current = _messages.value.toMutableList()
        current.add(0, message)
        // Keep at most 200 items
        val trimmed = if (current.size > 200) current.subList(0, 200) else current
        _messages.value = trimmed
        persist(trimmed)
    }

    @Synchronized
    fun clearMessages() {
        _messages.value = emptyList()
        vault.saveEncryptedHistory("[]")
    }

    private fun persist(list: List<UiMessage>) {
        try {
            val array = JSONArray()
            for (msg in list) {
                val obj = JSONObject()
                obj.put("id", msg.id)
                obj.put("type", msg.type)
                obj.put("timestampSec", msg.timestampSec)
                msg.latitude?.let { obj.put("latitude", it) }
                msg.longitude?.let { obj.put("longitude", it) }
                msg.mapsUrl?.let { obj.put("mapsUrl", it) }
                msg.bodyText?.let { obj.put("bodyText", it) }
                obj.put("receivedAtMs", msg.receivedAtMs)
                array.put(obj)
            }
            vault.saveEncryptedHistory(array.toString())
        } catch (_: Exception) {
            // Silently ignore storage failure
        }
    }
}
