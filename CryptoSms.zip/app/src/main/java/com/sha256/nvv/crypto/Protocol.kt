package com.sha256.nvv.crypto

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Protocol specification for GPS Tracker <-> Crypto SMS companion app.
 */
object Protocol {

    const val TAG_BIT_LENGTH = 128
    const val IV_LENGTH = 12
    const val GCM_TAG_LENGTH = 16

    // AAD bytes
    val AAD_TRACKER_TO_MONITOR: ByteArray = byteArrayOf(0x01)
    val AAD_MONITOR_TO_TRACKER: ByteArray = byteArrayOf(0x02)

    // Message Types
    const val TYPE_N1_LOCATION: Byte = 0x01
    const val TYPE_G7_ALERT: Byte = 0x02
    const val TYPE_CMD_JOY: Byte = 0x10
    const val TYPE_CMD_JOY_OVOZ: Byte = 0x11

    // Plaintext message regex check: Base64 string between 40 and 120 chars
    private val ENCRYPTED_BODY_REGEX = Regex("^[A-Za-z0-9+/]{40,120}={0,2}$")

    data class TrackerConfig(
        val keyBytes: ByteArray,
        val phone9: String,
        val code4: String,
        val name: String
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            other as TrackerConfig
            if (!keyBytes.contentEquals(other.keyBytes)) return false
            if (phone9 != other.phone9) return false
            if (code4 != other.code4) return false
            if (name != other.name) return false
            return true
        }

        override fun hashCode(): Int {
            var result = keyBytes.contentHashCode()
            result = 31 * result + phone9.hashCode()
            result = 31 * result + code4.hashCode()
            result = 31 * result + name.hashCode()
            return result
        }

        fun formattedPhone(): String {
            return formatUzPhone(phone9)
        }
    }

    sealed class IncomingMessage {
        abstract val timestampSec: Long

        data class N1Location(
            override val timestampSec: Long,
            val latitude: Double,
            val longitude: Double,
            val mapsUrl: String
        ) : IncomingMessage()

        data class G7Alert(
            override val timestampSec: Long,
            val message: String
        ) : IncomingMessage()

        data class PlainFallback(
            override val timestampSec: Long,
            val body: String,
            val mapsUrl: String?
        ) : IncomingMessage()
    }

    /**
     * Parse QR code content:
     * GT2;<keyBase64>;<phone9>;<code4>;<name>
     */
    fun parseQrCode(qrText: String): TrackerConfig? {
        val parts = qrText.split(";", limit = 5)
        if (parts.size != 5) return null
        if (parts[0] != "GT2") return null

        val keyBase64 = parts[1]
        val phone9 = parts[2]
        val code4 = parts[3]
        val name = parts[4]

        val keyBytes = try {
            decodeBase64(keyBase64)
        } catch (_: Exception) {
            return null
        }

        if (keyBytes.size != 32) return null
        if (!phone9.matches(Regex("^\\d{9}$"))) return null
        if (!code4.matches(Regex("^\\d{4}$"))) return null
        if (name.isEmpty()) return null

        return TrackerConfig(
            keyBytes = keyBytes,
            phone9 = phone9,
            code4 = code4,
            name = name
        )
    }

    /**
     * Checks whether an incoming SMS body appears to be encrypted.
     */
    fun looksEncrypted(body: String): Boolean {
        return ENCRYPTED_BODY_REGEX.matches(body.trim())
    }

    /**
     * Decrypt an incoming tracker SMS.
     * Wire format: Base64 of IV(12) + Ciphertext + Tag(16)
     * AAD = {0x01}
     */
    fun decryptIncoming(body: String, keyBytes: ByteArray): IncomingMessage? {
        val raw = try {
            decodeBase64(body.trim())
        } catch (_: Exception) {
            return null
        }

        if (raw.size < IV_LENGTH + GCM_TAG_LENGTH) return null

        val iv = raw.copyOfRange(0, IV_LENGTH)
        val cipherAndTag = raw.copyOfRange(IV_LENGTH, raw.size)

        val plaintext = try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val keySpec = SecretKeySpec(keyBytes, "AES")
            val gcmSpec = GCMParameterSpec(TAG_BIT_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmSpec)
            cipher.updateAAD(AAD_TRACKER_TO_MONITOR)
            cipher.doFinal(cipherAndTag)
        } catch (_: AEADBadTagException) {
            return null
        } catch (_: Exception) {
            return null
        }

        return parseIncomingPlaintext(plaintext)
    }

    /**
     * Parse decrypted tracker plaintext.
     */
    fun parseIncomingPlaintext(bytes: ByteArray): IncomingMessage? {
        if (bytes.isEmpty()) return null
        val type = bytes[0]

        when (type) {
            TYPE_N1_LOCATION -> {
                // Layout: [type:1][ts:4][lat:4][lng:4] = 13 bytes
                if (bytes.size != 13) return null

                val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
                buffer.get() // skip type byte
                val ts = buffer.int.toLong() and 0xFFFFFFFFL
                val intLat = buffer.int
                val intLng = buffer.int

                val lat = intLat / 1e7
                val lng = intLng / 1e7

                if (Math.abs(lat) > 90.0 || Math.abs(lng) > 180.0) return null

                val mapsUrl = buildMapsUrl(lat, lng)

                return IncomingMessage.N1Location(
                    timestampSec = ts,
                    latitude = lat,
                    longitude = lng,
                    mapsUrl = mapsUrl
                )
            }

            TYPE_G7_ALERT -> {
                // Layout: [type:1][ts:4] = 5 bytes
                if (bytes.size != 5) return null

                val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
                buffer.get() // skip type byte
                val ts = buffer.int.toLong() and 0xFFFFFFFFL

                return IncomingMessage.G7Alert(
                    timestampSec = ts,
                    message = "Qurilma administratori o'chirildi!"
                )
            }

            else -> return null
        }
    }

    /**
     * Build Google Maps URL with exact 7 decimals using Locale.US.
     */
    fun buildMapsUrl(latitude: Double, longitude: Double): String {
        return String.format(Locale.US, "https://maps.google.com/?q=%.7f,%.7f", latitude, longitude)
    }

    /**
     * Parse plaintext fallback SMS starting with "GPS Tracker:".
     */
    fun parsePlaintextFallback(body: String, currentTimestampSec: Long): IncomingMessage.PlainFallback? {
        if (!body.startsWith("GPS Tracker:")) return null

        val mapsRegex = Regex("https?://maps\\.google\\.com/\\S+")
        val match = mapsRegex.find(body)
        val mapsUrl = match?.value

        return IncomingMessage.PlainFallback(
            timestampSec = currentTimestampSec,
            body = body,
            mapsUrl = mapsUrl
        )
    }

    /**
     * Build and encrypt outgoing command (7 bytes):
     * [type: 1 byte][ts: 4 bytes unsigned][password: 2 bytes short]
     * AAD = {0x02}
     * Returns 48-char Base64 string.
     */
    fun buildAndEncryptCommand(
        type: Byte,
        tsSec: Long,
        code4: String,
        keyBytes: ByteArray
    ): String {
        val codeInt = (code4.toIntOrNull() ?: 0) and 0xFFFF

        val plaintext = ByteBuffer.allocate(7).order(ByteOrder.BIG_ENDIAN)
            .put(type)
            .putInt(tsSec.toInt())
            .putShort(codeInt.toShort())
            .array()

        val secureRandom = SecureRandom()
        val iv = ByteArray(IV_LENGTH)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(keyBytes, "AES")
        val gcmSpec = GCMParameterSpec(TAG_BIT_LENGTH, iv)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmSpec)
        cipher.updateAAD(AAD_MONITOR_TO_TRACKER)
        val cipherAndTag = cipher.doFinal(plaintext)

        val fullPayload = ByteArray(IV_LENGTH + cipherAndTag.size)
        System.arraycopy(iv, 0, fullPayload, 0, IV_LENGTH)
        System.arraycopy(cipherAndTag, 0, fullPayload, IV_LENGTH, cipherAndTag.size)

        return encodeBase64(fullPayload)
    }

    fun formatUzPhone(phone9: String): String {
        if (phone9.length != 9) return phone9
        return "+998 " + phone9.substring(0, 2) + " " +
                phone9.substring(2, 5) + " " +
                phone9.substring(5, 7) + " " +
                phone9.substring(7, 9)
    }

    fun formatDateTime(timestampSec: Long): String {
        val date = Date(timestampSec * 1000)
        val sdf = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
        return sdf.format(date)
    }

    fun encodeBase64(data: ByteArray): String {
        return Base64.getEncoder().encodeToString(data)
    }

    fun decodeBase64(str: String): ByteArray {
        return Base64.getDecoder().decode(str.trim())
    }
}
