# Crypto SMS (Native Android)

**Crypto SMS** (`com.sha256.nvv`) — "GPS Tracker" (`com.gpstracker.app`) ilovasi uchun shifrlangan monitoring va masofaviy boshqaruv hamrohi.

---

## Asosiy xususiyatlari

- **Offline va xavfsiz**: `INTERNET` ruxsati yo'q, tarmoqqa so'rovlar yuborilmaydi, analitika mavjud emas.
- **QR orqali tezkor bog'lanish**: GPS Tracker ekranidagi QR kodni CameraX va ZXing yordamida skanerlab 32-baytli AES-256 kalit, telefon raqami va maxfiy parolni xavfsiz bog'laydi.
- **AES-256-GCM shifrlash**:
  - Tracker -> Monitor: AAD = `0x01`
  - Monitor -> Tracker: AAD = `0x02`
  - Wire formati: Base64(IV[12] + Ciphertext + Tag[16])
- **N1 Joylashuv protokoli**: 13 baytli binar paket, 7 xonali Google Maps havolasi (`https://maps.google.com/?q=lat,lng`).
- **G7 Ogohlantirish**: Qurilma administratori o'chirilganda darhol qizil ogohlantirish ko'rsatish.
- **Buyruqlar**:
  - `JOY` (0x10) — Joriy koordinatani so'rash (rate limit: 10s, javob 5 daqiqada 1 marta keladi).
  - `JOY OVOZ` (0x11) — Telefon sirenasini chaldirish (tasdiqlash muloqot oynasi bilan).
- **Xavfsizlik**:
  - `FLAG_SECURE`: Skrinshotlar va ekran yozuvlari bloklangan.
  - Android Keystore master kaliti orqali barcha ma'lumotlar SharedPreferences'da shifrlangan holda saqlanadi.
  - 4 xonali PIN kod (PBKDF2-HMAC-SHA256, 100 000 iteratsiya), 5 ta xato urinishdan so'ng vaqtli bloklash.
  - Fondan 60 soniya o'tgach avtomatik qulflash.

---

## Qurish (Build)

Ushbu loyiha Gradle 9.6.0 va Android Gradle Plugin 9.4.0 (Kotlin Compose Compiler 2.3.21) yordamida quriladi:

```bash
# Debug APK yaratish
gradle assembleDebug --console=plain

# Unit testlarni yurgizish
gradle testDebugUnitTest
```

Yaratilgan APK fayl:
`app/build/outputs/apk/debug/app-debug.apk`

---

## GitHub orqali APK olish (Qadamma-qadam)

1. Loyiha fayllarini zip qilib GitHub reposingizga yuklang (`git push origin main`).
2. Repositoriyning **Actions** bo'limiga o'ting.
3. **Build Debug APK** workflow avtomatik ishga tushadi yoki `Run workflow` tugmasini bosing.
4. Jarayon yakunlangach, **Artifacts** bo'limidan `app-debug` faylini yuklab oling va telefonga o'rnating.
