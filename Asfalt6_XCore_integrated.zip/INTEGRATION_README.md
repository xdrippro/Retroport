# Asfalt 6 XCore — integrated J2ME-Loader source

This project embeds the upstream J2ME-Loader application/runtime source and
bundles `app/src/main/assets/game.jar` (the provided Asphalt 6 JAR).

## Flow
1. XCoreLauncherActivity shows a simple splash screen and stages the JAR.
2. Agree & Continue passes the staged JAR to the upstream MainActivity/importer.
3. J2ME-Loader's AppInstaller converts the JAR into its required DEX/config
   representation and stores the game in the emulator's app directory.
4. After conversion, the installer dialog auto-continues to run the MIDlet.
5. The upstream runtime may still ask for per-game configuration on first run;
   J2ME-Loader requires a profile before MicroActivity can start the game.

## Build
Use JDK 21 and Android SDK/NDK. GitHub Actions downloads the TinySoundFont
native dependency and runs `./gradlew assembleOpenDebug`.

## Important limitations
- This is source-level integration, not a verified successful build in this
  environment. Android Gradle Plugin/SDK/NDK compatibility must be confirmed
  by running the workflow.
- JAR conversion and gameplay have not been tested here.
- The upstream emulator runtime/native libraries are included, so APK size
  may exceed 10–15 MB. This is not a lightweight AAR-only build.
- Keep the upstream Apache-2.0 license and notices in the repository.
- Use game files only when you have the right to use/distribute them.
