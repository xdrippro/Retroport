LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := javam3g
LOCAL_CFLAGS    := -O3 -DM3G_TARGET_ANDROID -DM3G_GL_ES_1_1 #-DM3G_DEBUG
LOCAL_CXXFLAGS  := $(LOCAL_CFLAGS)
LOCAL_LDLIBS    := -llog -lEGL -lGLESv1_CM -lz -ljnigraphics
LOCAL_LDFLAGS += -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384
LOCAL_C_INCLUDES := $(LOCAL_PATH)/inc/
LOCAL_SRC_FILES := \
	CSynchronization.cpp \
	m3g_android_java_api.cpp \
	src/m3g_core.c \
	src/m3g_android.cpp \
	src/m3g_android_gl.cpp

# Don't strip debug builds
ifeq ($(NDK_DEBUG),1)
    cmd-strip :=
endif

include $(BUILD_SHARED_LIBRARY)
