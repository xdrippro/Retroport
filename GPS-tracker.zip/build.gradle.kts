// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "9.4.0" apply false
    // Kotlin AGP 9 ichiga o'rnatilgan (built-in Kotlin). Compose kompilyatori Kotlin versiyasiga mos bo'lishi shart.
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
