-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses

# OkHttp qoidalari
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }

# Google Play Services Location
-keep class com.google.android.gms.location.** { *; }
