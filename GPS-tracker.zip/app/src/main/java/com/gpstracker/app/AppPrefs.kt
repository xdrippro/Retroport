package com.gpstracker.app

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Sozlamalar ombori. Bot Token Android Keystore'dagi AES-GCM kaliti bilan shifrlanib saqlanadi
 * (oddiy matn sifatida SharedPreferences'da turmaydi). Kalit qurilmadan chiqmaydi.
 */
object AppPrefs {
    const val PREFS_NAME = "gps_tracker_prefs"
    const val KEY_USER_NAME = "user_name"
    const val KEY_CHAT_ID = "chat_id"
    const val KEY_TRACKING = "is_tracking_active"
    const val KEY_LOCATION_FAILS = "location_fail_count"
    const val KEY_SEND_FAILS = "send_fail_count"

    private const val KEY_TOKEN_ENC = "bot_token_enc"
    private const val LEGACY_KEY_TOKEN = "bot_token" // eski versiyada oddiy matn sifatida saqlangan
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "gpstracker_token_key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG = "AppPrefs"

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Shifrlangan tokenni o'qiydi. Topilmasa yoki ochilmasa bo'sh satr qaytaradi. */
    fun getBotToken(context: Context): String {
        val p = prefs(context)
        val encrypted = p.getString(KEY_TOKEN_ENC, null)
        if (encrypted != null) {
            return decrypt(encrypted) ?: ""
        }

        // Eski versiyadan o'tkazish: oddiy matndagi tokenni shifrlab, eskisini o'chirish
        val legacy = p.getString(LEGACY_KEY_TOKEN, null)
        if (!legacy.isNullOrBlank()) {
            setBotToken(context, legacy)
            return legacy
        }
        return ""
    }

    /** Tokenni shifrlab saqlaydi. Muvaffaqiyatli bo'lsa true. Bo'sh token saqlangan tokenni o'chiradi. */
    fun setBotToken(context: Context, token: String): Boolean {
        val editor = prefs(context).edit()
        if (token.isBlank()) {
            editor.remove(KEY_TOKEN_ENC).remove(LEGACY_KEY_TOKEN).apply()
            return true
        }
        return try {
            editor.putString(KEY_TOKEN_ENC, encrypt(token)).remove(LEGACY_KEY_TOKEN).apply()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Tokenni shifrlashda xatolik: ${e.javaClass.simpleName}")
            false
        }
    }

    internal fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
        keyStore.load(null)
        val existing = keyStore.getKey(KEY_ALIAS, null)
        if (existing is SecretKey) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" +
                Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(stored: String): String? {
        return try {
            val parts = stored.split(":")
            if (parts.size != 2) return null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.e(TAG, "Tokenni ochishda xatolik: ${e.javaClass.simpleName}")
            null
        }
    }
}
