package com.gpstracker.app

import android.os.SystemClock
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ilova oynasi qulfi holati. Faqat ekran (UI) uchun: GPS xizmati bunga bog'liq emas.
 * Ilova fonga o'tib, GRACE_MS dan uzoq turib qolsa, qaytganda yana PIN so'raladi.
 * Jarayon (process) o'chib qayta ochilsa, har doim qulflangan holda boshlanadi.
 */
object SessionLock {
    private const val GRACE_MS = 60_000L

    var unlocked by mutableStateOf(false)

    private var leftAt = 0L

    fun onLeave() {
        leftAt = SystemClock.elapsedRealtime()
    }

    fun onEnter() {
        if (unlocked && leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > GRACE_MS) {
            unlocked = false
        }
    }
}

@Composable
fun AppRoot(
    stopRequested: Boolean,
    onStopRequestHandled: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasPin by remember { mutableStateOf(PinManager.hasPin(context)) }

    if (!hasPin) {
        // Birinchi ishga tushirish (yoki PIN hali o'rnatilmagan): PIN o'rnatish majburiy
        CreatePinScreen(title = "PIN kod o'rnating") { newPin ->
            scope.launch {
                withContext(Dispatchers.Default) {
                    PinManager.setPin(context, newPin)
                }
                hasPin = true
                SessionLock.unlocked = true
            }
        }
    } else if (!SessionLock.unlocked) {
        VerifyPinScreen(subtitle = "Ilovaga kirish uchun PIN kodni kiriting") {
            SessionLock.unlocked = true
        }
    } else {
        TrackerAppScreen(
            stopRequested = stopRequested,
            onStopRequestHandled = onStopRequestHandled
        )
    }
}
