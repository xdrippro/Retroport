package com.gpstracker.app

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Ilovaga kirish PIN kodi.
 * PIN oddiy matn sifatida saqlanmaydi: tasodifiy "tuz" (salt) bilan PBKDF2 xeshi saqlanadi.
 * Ketma-ket noto'g'ri urinishlardan keyin vaqtincha qulflanadi.
 */
object PinManager {
    const val PIN_LENGTH = 4

    private const val KEY_SALT = "pin_salt"
    private const val KEY_HASH = "pin_hash"
    private const val KEY_FAILS = "pin_fail_count"
    private const val KEY_LOCKED_UNTIL = "pin_locked_until"

    private const val ITERATIONS = 100_000
    private const val TRIES_BEFORE_LOCK = 5
    private const val BASE_LOCK_SECONDS = 30L
    private const val MAX_LOCK_SECONDS = 900L

    fun hasPin(context: Context): Boolean =
        AppPrefs.prefs(context).contains(KEY_HASH)

    /** Yangi PIN ni saqlaydi (xesh hisoblash biroz vaqt oladi, asosiy oqimdan tashqarida chaqiring). */
    fun setPin(context: Context, pin: String) {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val hash = hashPin(pin, salt)
        AppPrefs.prefs(context).edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .putInt(KEY_FAILS, 0)
            .putLong(KEY_LOCKED_UNTIL, 0L)
            .apply()
    }

    fun verifyPin(context: Context, pin: String): Boolean {
        val prefs = AppPrefs.prefs(context)
        val saltText = prefs.getString(KEY_SALT, null) ?: return false
        val hashText = prefs.getString(KEY_HASH, null) ?: return false
        return try {
            val expected = Base64.decode(hashText, Base64.NO_WRAP)
            val actual = hashPin(pin, Base64.decode(saltText, Base64.NO_WRAP))
            MessageDigest.isEqual(expected, actual)
        } catch (e: Exception) {
            false
        }
    }

    /** Qulf tugashiga qolgan vaqt (millisekund). 0 bo'lsa, qulflanmagan. */
    fun lockRemainingMs(context: Context): Long {
        val until = AppPrefs.prefs(context).getLong(KEY_LOCKED_UNTIL, 0L)
        val remaining = until - System.currentTimeMillis()
        return if (remaining > 0L) remaining else 0L
    }

    /** Noto'g'ri urinishni qayd etadi. Qulf boshlansa, qulf davomiyligini (ms) qaytaradi, aks holda 0. */
    fun registerFailure(context: Context): Long {
        val prefs = AppPrefs.prefs(context)
        val fails = prefs.getInt(KEY_FAILS, 0) + 1
        var lockMs = 0L
        if (fails % TRIES_BEFORE_LOCK == 0) {
            val level = fails / TRIES_BEFORE_LOCK
            val doublings = if (level - 1 > 5) 5 else level - 1
            var seconds = BASE_LOCK_SECONDS * (1L shl doublings)
            if (seconds > MAX_LOCK_SECONDS) seconds = MAX_LOCK_SECONDS
            lockMs = seconds * 1000L
        }
        prefs.edit()
            .putInt(KEY_FAILS, fails)
            .putLong(KEY_LOCKED_UNTIL, if (lockMs > 0L) System.currentTimeMillis() + lockMs else 0L)
            .apply()
        return lockMs
    }

    fun registerSuccess(context: Context) {
        AppPrefs.prefs(context).edit()
            .putInt(KEY_FAILS, 0)
            .putLong(KEY_LOCKED_UNTIL, 0L)
            .apply()
    }

    private fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }
}
